package com.example.prueba;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    private ListView listview;
    private ArrayList<String> nombresCiudades;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        setupListView();
    }

    public void setupListView(){
        listview = findViewById(R.id.lista);
        nombresCiudades = new ArrayList<String>();
        nombresCiudades.add("Londres");
        nombresCiudades.add("Córdoba");
        nombresCiudades.add("New York");
        nombresCiudades.add("Tokio");
        nombresCiudades.add("Madrid");


        // ArrayAdapter arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, nombresCiudades);


        CustomAdapter customAdapter = new CustomAdapter(this, android.R.layout.simple_list_item_1, nombresCiudades);

        listview.setAdapter(customAdapter);

         listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {


             @Override
             public void onItemClick(AdapterView adapterView, View view, int position, long id) {
                goToDetail(nombresCiudades.get(position));
            }
        });

    } ;

    private  void goToDetail(String name) {
        Intent myIntent = new Intent(this, DetailActivity.class);
        myIntent.putExtra("nombreDeCiudad",name);
        startActivity(myIntent);
    }

    }


