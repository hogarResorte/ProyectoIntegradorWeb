package com.example.prueba;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<String> nombresCiudades;

    public CustomAdapter(Context context, int layout, ArrayList<String> nombresCiudades) {
        this.context = context;
        this.layout = layout;
        this.nombresCiudades = nombresCiudades;
    }

    @Override
    public int getCount() {
        return nombresCiudades.size();
    }

    @Override
    public Object getItem(int i) {
        return this.nombresCiudades.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        // Copiamos la vista
        View vista = view;
        //Inflamos la vista con nuestro propio layout
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);

        vista = layoutInflater.inflate(R.layout.item_list, null);

        // Valor actual según la posición
        String currentName = nombresCiudades.get(i);

        // Referenciamos el elemento a modificar y lo rellenamos
        TextView textView = (TextView) vista.findViewById(R.id.textView);
        textView.setText(currentName);
        //Devolvemos la vista inflada
        return vista;
    }
}

