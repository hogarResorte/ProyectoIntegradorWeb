package com.example.prueba;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    
    public void listadoCiudades(View view) {
        Intent myIntent = new Intent(this, ListActivity.class);
        startActivity(myIntent);

    }

    public void goToDetail(View view){
        //Iniciamos una nueva activity y pasamos como parametro la latitud y longitud
        Intent myIntent = new Intent(this, DetailActivity.class);
        myIntent.putExtra("lat", -32.23907470f);
        myIntent.putExtra("lon",  -63.97744750f);
        startActivity(myIntent);

    }

}