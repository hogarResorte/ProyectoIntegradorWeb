package com.example.prueba;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface API {
    String BASE_URL = "https://api.openweathermap.org/data/2.5/";
    String TOKEN = "bf13b58a61f6a8c6b0d310eb64aee90e";
    String UNITS = "metric";
    String LANG = "es";


    @GET("weather") //https://api.openweathermap.org/data/2.5/weather?lat=-32.23907470&lon=-63.97744750&appid=bf13b58a61f6a8c6b0d310eb64aee90e&units=metric&lang=es
    Call<Results> getActualWeather(@Query("lat") float lat,
                                   @Query("lon") float lon,
                                   @Query("appid") String token,
                                   @Query("units") String units,
                                   @Query("lang") String lang);
}
