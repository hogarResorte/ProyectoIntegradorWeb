package com.example.prueba;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailActivity extends AppCompatActivity {
    TextView nombreCiudad, tempActual, description, tempMin, tempMax, minima, maxima;
    Float lat, lon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent myIntent = getIntent();
       // String name = myIntent.getStringExtra("nombreDeCiudad");
       // TextView nameTextView = findViewById(R.id.description);
    // nameTextView.setText(name);

        //PronósticoActual
        myIntent.getFloatExtra("lat",0.0f);
        myIntent.getFloatExtra("lon",0.0f);

        //Obtenemos los textview
        nombreCiudad = findViewById(R.id.nombreCiudad);
        tempActual = findViewById(R.id.tempActual);
        description = findViewById(R.id.description);
        tempMin = findViewById(R.id.tempMin);
        tempMax = findViewById(R.id.tempMax);
        minima = findViewById(R.id.minima);
        maxima = findViewById(R.id.maxima);

        getActualWeather();
    }

    private void getActualWeather(){
        Call<Results> call = RetrofitClient.getInstance().getMyApi().getActualWeather(lat, lon, API.TOKEN, API.UNITS, API.LANG);
        call.enqueue(new Callback<Results>() {
            @Override
            public void onResponse(Call<Results> call, Response<Results> response) {
                Results results = response.body();
                nombreCiudad.setText((results.name));
                tempActual.setText(String.valueOf(results.main.temp.shortValue()) + "º");
                tempMin.setText(String.valueOf(results.main.temp_min.shortValue()) + "º");
                tempMax.setText(String.valueOf(results.main.temp_max.shortValue())+ "º");
                Results.Weather weather = results.weather.get(0);
                description.setText(weather.description);
            }

            @Override
            public void onFailure(Call<Results> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Hubo un error, intente más tarde", Toast.LENGTH_LONG).show();
            }
        });
    };




    }
